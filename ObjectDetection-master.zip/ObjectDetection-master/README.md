# ObjectDetection
•	Organized and Collaborated in a team to achieve object detection for cars via deep learning.

•	Researched on Tensorflow API, different object detection models: R-CNN, YOLO, Fast R-CNN, Faster R-CNN.

•	Retrained a pretrained model: faster_rcnn_resnet101_coco_2018_01_28 on Google Cloud on KITTI dataset.

•	Tested and evaluated our model with new images and analyzed the performance using monitor: TensorBoard.
